import React from "react";
import { render } from "react-dom";
import { Header } from "./components/Header.js";
import { Home } from "./components/Home.js"

class App extends React.Component {
	
	constructor(){
		super();
		this.state = {
			HeaderTitle : "default header"
		}
	}
	onGreet(){
		alert("hi");
	}
	onChangeHeader(newName){
		this.setState({
			HeaderTitle : newName
		})
	}
	render(){
		var user= {
			userId : 215,
			Hobbies : ["sports1","sports2"]
		}
		return (
		   <div className="container">
			<Header/>
			  <div className="row">
			       <div className="col-xs-10 col-xs-offset-1">
			         <h1>{this.state.HeaderTitle}</h1>
			        <Home name={'prashanth'} user = {user} greet= {this.onGreet} changeHeader = {this.onChangeHeader.bind(this)}>
			            <p> child.</p> 
			        </Home>
			        
			       </div>
			   </div>
			
			
		   </div>
		);
	}
}
render(<App/>,window.document.getElementById("app"))